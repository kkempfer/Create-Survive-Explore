## A very simple datapack that adds 2 recipes to [Man of Many Planes](https://modrinth.com/mod/man-of-many-planes) 

Requires [Create](https://modrinth.com/mod/create), [Man of Many Planes](https://modrinth.com/mod/man-of-many-planes) and [Immersive Aircraft](https://modrinth.com/mod/immersive-aircraft)

Reccomended to be used with [Create Immersive Aircrafts - Recipes](https://www.curseforge.com/minecraft/texture-packs/create-immersive-aircrafts-data-pack) and [Create Immersive Aircrafts](https://www.curseforge.com/minecraft/texture-packs/create-immersive-aircrafts-resource-pack)

### Recipes:
- **Economy Plane**
![Screenshot of the Economy Plane and the recipe for it in Mechanical Crafters with mountains in the background and a tree](https://github.com/Fugimii/Create-Man-of-Many-Planes/blob/main/images/2024-05-30_18.12.17.jpg?raw=true)

- **Scarlet Biplane**
![Screenshot of the Scarlet Biplane and the recipe for it in Mechanical Crafters with mountains in the background and a tree](https://github.com/Fugimii/Create-Man-of-Many-Planes/blob/main/images/2024-05-30_18.10.07.jpg?raw=true)

## Feel free to include in modpacks :)
